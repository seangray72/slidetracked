/**
 * Map Management Module
 * Handles all map-related functionality including initialization, markers, and track visualization
 */

class MapManager {
    constructor() {
        this.map = null;
        this.carMarker = null;
        this.trackPolyline = null;
        this.trackPoints = [];
        this.baseStationMarker = null;
        this.isSatelliteView = false;
        this.isFollowingCar = true;
        
        // Layer groups
        this.trackLayerGroup = null;
        
        // Map tile layers
        this.osmLayer = null;
        this.satelliteLayer = null;
        
        this.initializeMap();
        this.setupEventListeners();
    }

    initializeMap() {
        // Initialize the map centered on a default location
        this.map = L.map('map', {
            center: [40.7128, -74.0060], // New York City default
            zoom: 18,
            zoomControl: true,
            attributionControl: true
        });

        // Create tile layers
        this.osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 19
        });

        this.satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            attribution: '© Esri, Maxar, GeoEye, Earthstar Geographics, CNES/Airbus DS, USDA, USGS, AeroGRID, IGN, and the GIS User Community',
            maxZoom: 19
        });

        // Add default layer
        this.osmLayer.addTo(this.map);

        // Initialize layer groups
        this.trackLayerGroup = L.layerGroup().addTo(this.map);

        // Custom car icon
        this.carIcon = L.divIcon({
            className: 'car-marker',
            html: '<i class="fas fa-car" style="color: #667eea; font-size: 20px; text-shadow: 2px 2px 4px rgba(0,0,0,0.5);"></i>',
            iconSize: [30, 30],
            iconAnchor: [15, 15]
        });

        // Base station icon
        this.baseStationIcon = L.divIcon({
            className: 'base-station-marker',
            html: '<i class="fas fa-broadcast-tower" style="color: #e53e3e; font-size: 18px; text-shadow: 2px 2px 4px rgba(0,0,0,0.5);"></i>',
            iconSize: [25, 25],
            iconAnchor: [12, 12]
        });

        console.log('Map initialized successfully');
    }

    setupEventListeners() {
        // Center map button
        document.getElementById('center-map').addEventListener('click', () => {
            this.centerOnCar();
        });

        // Toggle satellite view
        document.getElementById('toggle-satellite').addEventListener('click', () => {
            this.toggleSatelliteView();
        });

        // Fullscreen toggle
        document.getElementById('fullscreen-map').addEventListener('click', () => {
            this.toggleFullscreen();
        });

        // Map click event - disable following when user manually interacts
        this.map.on('drag', () => {
            this.isFollowingCar = false;
        });

        this.map.on('zoom', () => {
            // Only disable following if it's a manual zoom (not programmatic)
            if (!this._programmicZoom) {
                this.isFollowingCar = false;
            }
        });
    }

    updateCarPosition(position) {
        const { latitude, longitude, altitude, speed, heading } = position;
        const latLng = [latitude, longitude];

        // Create or update car marker
        if (this.carMarker) {
            this.carMarker.setLatLng(latLng);
        } else {
            this.carMarker = L.marker(latLng, { 
                icon: this.carIcon,
                rotationAngle: heading || 0,
                rotationOrigin: 'center'
            }).addTo(this.map);
            
            // Add popup with car info
            this.carMarker.bindPopup(`
                <div style="font-family: Inter, sans-serif;">
                    <strong>🚗 Drift Car</strong><br>
                    <small>Lat: ${latitude.toFixed(6)}</small><br>
                    <small>Lng: ${longitude.toFixed(6)}</small><br>
                    <small>Alt: ${altitude.toFixed(1)}m</small><br>
                    <small>Speed: ${speed.toFixed(1)} km/h</small>
                </div>
            `);
        }

        // Update marker rotation if heading is available
        if (heading !== undefined && this.carMarker._icon) {
            this.carMarker._icon.style.transform += ` rotate(${heading}deg)`;
        }

        // Center map on car if following mode is enabled
        if (this.isFollowingCar) {
            this._programmicZoom = true;
            this.map.setView(latLng, this.map.getZoom(), { animate: true });
            setTimeout(() => { this._programmicZoom = false; }, 100);
        }

        // Add point to track if recording
        if (window.gpsTracker && window.gpsTracker.isRecording) {
            this.addTrackPoint(position);
        }

        console.log(`Car position updated: ${latitude.toFixed(6)}, ${longitude.toFixed(6)}`);
    }

    setBaseStationPosition(latitude, longitude) {
        const latLng = [latitude, longitude];

        if (this.baseStationMarker) {
            this.baseStationMarker.setLatLng(latLng);
        } else {
            this.baseStationMarker = L.marker(latLng, { 
                icon: this.baseStationIcon 
            }).addTo(this.map);
            
            this.baseStationMarker.bindPopup(`
                <div style="font-family: Inter, sans-serif;">
                    <strong>📡 Base Station</strong><br>
                    <small>RTK3B Budget</small><br>
                    <small>Lat: ${latitude.toFixed(6)}</small><br>
                    <small>Lng: ${longitude.toFixed(6)}</small>
                </div>
            `);
        }

        console.log(`Base station position set: ${latitude.toFixed(6)}, ${longitude.toFixed(6)}`);
    }

    addTrackPoint(position) {
        const { latitude, longitude, timestamp } = position;
        
        // Add point to track array
        this.trackPoints.push({
            lat: latitude,
            lng: longitude,
            timestamp: timestamp || Date.now(),
            ...position
        });

        // Update polyline
        this.updateTrackPolyline();
    }

    updateTrackPolyline() {
        if (this.trackPoints.length < 2) return;

        // Create polyline coordinates
        const coordinates = this.trackPoints.map(point => [point.lat, point.lng]);

        if (this.trackPolyline) {
            // Update existing polyline
            this.trackPolyline.setLatLngs(coordinates);
        } else {
            // Create new polyline
            this.trackPolyline = L.polyline(coordinates, {
                color: '#667eea',
                weight: 4,
                opacity: 0.8,
                smoothFactor: 1
            }).addTo(this.trackLayerGroup);

            // Add click event to show track info
            this.trackPolyline.on('click', (e) => {
                const popup = L.popup()
                    .setLatLng(e.latlng)
                    .setContent(`
                        <div style="font-family: Inter, sans-serif;">
                            <strong>🏁 Track Point</strong><br>
                            <small>Total Points: ${this.trackPoints.length}</small><br>
                            <small>Distance: ${this.calculateTrackDistance().toFixed(2)} km</small>
                        </div>
                    `)
                    .openOn(this.map);
            });
        }
    }

    calculateTrackDistance() {
        if (this.trackPoints.length < 2) return 0;

        let totalDistance = 0;
        for (let i = 1; i < this.trackPoints.length; i++) {
            const prev = this.trackPoints[i - 1];
            const curr = this.trackPoints[i];
            totalDistance += this.haversineDistance(
                prev.lat, prev.lng,
                curr.lat, curr.lng
            );
        }
        return totalDistance;
    }

    haversineDistance(lat1, lon1, lat2, lon2) {
        const R = 6371; // Earth's radius in kilometers
        const dLat = this.degreesToRadians(lat2 - lat1);
        const dLon = this.degreesToRadians(lon2 - lon1);
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                  Math.cos(this.degreesToRadians(lat1)) * Math.cos(this.degreesToRadians(lat2)) *
                  Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }

    degreesToRadians(degrees) {
        return degrees * (Math.PI / 180);
    }

    clearTrack() {
        this.trackPoints = [];
        if (this.trackPolyline) {
            this.trackLayerGroup.removeLayer(this.trackPolyline);
            this.trackPolyline = null;
        }
        console.log('Track cleared');
    }

    centerOnCar() {
        if (this.carMarker) {
            this.map.setView(this.carMarker.getLatLng(), 18, { animate: true });
            this.isFollowingCar = true;
            console.log('Centered map on car');
        }
    }

    toggleSatelliteView() {
        if (this.isSatelliteView) {
            this.map.removeLayer(this.satelliteLayer);
            this.map.addLayer(this.osmLayer);
            this.isSatelliteView = false;
            document.getElementById('toggle-satellite').innerHTML = '<i class="fas fa-satellite"></i>';
        } else {
            this.map.removeLayer(this.osmLayer);
            this.map.addLayer(this.satelliteLayer);
            this.isSatelliteView = true;
            document.getElementById('toggle-satellite').innerHTML = '<i class="fas fa-map"></i>';
        }
        console.log(`Satellite view: ${this.isSatelliteView ? 'enabled' : 'disabled'}`);
    }

    toggleFullscreen() {
        const mapContainer = document.querySelector('.map-container');
        
        if (!document.fullscreenElement) {
            mapContainer.requestFullscreen().then(() => {
                // Invalidate size after entering fullscreen
                setTimeout(() => {
                    this.map.invalidateSize();
                }, 100);
                document.getElementById('fullscreen-map').innerHTML = '<i class="fas fa-compress"></i>';
            }).catch(err => {
                console.error('Error entering fullscreen:', err);
            });
        } else {
            document.exitFullscreen().then(() => {
                // Invalidate size after exiting fullscreen
                setTimeout(() => {
                    this.map.invalidateSize();
                }, 100);
                document.getElementById('fullscreen-map').innerHTML = '<i class="fas fa-expand"></i>';
            });
        }
    }

    exportTrackAsGPX() {
        if (this.trackPoints.length === 0) {
            console.warn('No track data to export');
            return null;
        }

        const gpxHeader = `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="RTK Drift Tracker">
  <trk>
    <name>Drift Track ${new Date().toISOString().split('T')[0]}</name>
    <trkseg>`;

        const gpxFooter = `    </trkseg>
  </trk>
</gpx>`;

        const trackPoints = this.trackPoints.map(point => {
            const timestamp = new Date(point.timestamp).toISOString();
            return `      <trkpt lat="${point.lat}" lon="${point.lng}">
        <ele>${point.altitude || 0}</ele>
        <time>${timestamp}</time>
        <extensions>
          <speed>${point.speed || 0}</speed>
          <hdop>${point.hdop || 0}</hdop>
        </extensions>
      </trkpt>`;
        }).join('\n');

        return gpxHeader + '\n' + trackPoints + '\n' + gpxFooter;
    }

    getTrackStatistics() {
        if (this.trackPoints.length === 0) {
            return {
                distance: 0,
                maxSpeed: 0,
                duration: 0,
                points: 0
            };
        }

        const distance = this.calculateTrackDistance();
        const speeds = this.trackPoints.map(p => p.speed || 0);
        const maxSpeed = Math.max(...speeds);
        
        const startTime = this.trackPoints[0].timestamp;
        const endTime = this.trackPoints[this.trackPoints.length - 1].timestamp;
        const duration = endTime - startTime;

        return {
            distance: distance,
            maxSpeed: maxSpeed,
            duration: duration,
            points: this.trackPoints.length
        };
    }
}

// Global map instance
window.mapManager = null;