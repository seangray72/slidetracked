/**
 * WebSocket Communication Module
 * Handles real-time communication with the rover via WebSocket
 */

class WebSocketManager {
    constructor() {
        this.ws = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectTimeout = null;
        this.isConnecting = false;
        this.url = null;
        
        // Connection status callbacks
        this.onStatusChange = null;
        this.onMessage = null;
        this.onError = null;
    }

    connect(ip, port) {
        if (this.isConnecting || (this.ws && this.ws.readyState === WebSocket.CONNECTING)) {
            console.log('Connection already in progress');
            return;
        }

        this.url = `ws://${ip}:${port}`;
        this.isConnecting = true;
        
        try {
            console.log(`Attempting to connect to ${this.url}`);
            this.updateStatus('connecting', 'Connecting...');
            
            this.ws = new WebSocket(this.url);
            this.setupEventListeners();
            
            // Connection timeout
            const timeout = setTimeout(() => {
                if (this.ws.readyState === WebSocket.CONNECTING) {
                    this.ws.close();
                    this.handleConnectionError('Connection timeout');
                }
            }, 10000); // 10 second timeout

            this.ws.onopen = () => {
                clearTimeout(timeout);
                this.onConnectionOpen();
            };

        } catch (error) {
            this.isConnecting = false;
            this.handleConnectionError(error.message);
        }
    }

    setupEventListeners() {
        if (!this.ws) return;

        this.ws.onopen = () => this.onConnectionOpen();
        this.ws.onmessage = (event) => this.onMessageReceived(event);
        this.ws.onclose = (event) => this.onConnectionClose(event);
        this.ws.onerror = (error) => this.onConnectionError(error);
    }

    onConnectionOpen() {
        console.log('WebSocket connected successfully');
        this.isConnecting = false;
        this.reconnectAttempts = 0;
        this.updateStatus('connected', 'Connected');
        
        // Send initial handshake
        this.send({
            type: 'handshake',
            client: 'web-ui',
            timestamp: Date.now()
        });

        // Update UI
        this.enableDisconnectButton();
        
        if (window.messageManager) {
            window.messageManager.addMessage('success', 'Connected to rover successfully');
        }
    }

    onMessageReceived(event) {
        try {
            const data = JSON.parse(event.data);
            console.log('Received message:', data);
            
            // Handle different message types
            switch (data.type) {
                case 'gps_position':
                    this.handleGPSPosition(data);
                    break;
                case 'gps_status':
                    this.handleGPSStatus(data);
                    break;
                case 'system_status':
                    this.handleSystemStatus(data);
                    break;
                case 'error':
                    this.handleError(data);
                    break;
                case 'handshake_response':
                    this.handleHandshakeResponse(data);
                    break;
                default:
                    console.log('Unknown message type:', data.type);
            }
            
            // Call external message handler if set
            if (this.onMessage) {
                this.onMessage(data);
            }
            
        } catch (error) {
            console.error('Error parsing message:', error);
            if (window.messageManager) {
                window.messageManager.addMessage('error', 'Error parsing received data');
            }
        }
    }

    onConnectionClose(event) {
        console.log('WebSocket connection closed:', event.code, event.reason);
        this.isConnecting = false;
        this.updateStatus('disconnected', 'Disconnected');
        this.enableConnectButton();
        
        if (window.messageManager) {
            if (event.wasClean) {
                window.messageManager.addMessage('info', 'Disconnected from rover');
            } else {
                window.messageManager.addMessage('warning', `Connection lost: ${event.reason || 'Unknown reason'}`);
            }
        }

        // Attempt to reconnect if it wasn't a clean disconnect
        if (!event.wasClean && this.reconnectAttempts < this.maxReconnectAttempts) {
            this.scheduleReconnect();
        }
    }

    onConnectionError(error) {
        console.error('WebSocket error:', error);
        this.isConnecting = false;
        
        if (this.onError) {
            this.onError(error);
        }
    }

    handleConnectionError(message) {
        console.error('Connection error:', message);
        this.updateStatus('disconnected', 'Connection failed');
        this.enableConnectButton();
        
        if (window.messageManager) {
            window.messageManager.addMessage('error', `Connection failed: ${message}`);
        }
    }

    handleGPSPosition(data) {
        const position = {
            latitude: data.latitude,
            longitude: data.longitude,
            altitude: data.altitude,
            speed: data.speed,
            heading: data.heading,
            timestamp: data.timestamp
        };

        // Update map
        if (window.mapManager) {
            window.mapManager.updateCarPosition(position);
        }

        // Update UI
        if (window.gpsTracker) {
            window.gpsTracker.updatePosition(position);
        }
    }

    handleGPSStatus(data) {
        if (window.gpsTracker) {
            window.gpsTracker.updateStatus({
                fixType: data.fix_type,
                satellites: data.satellites,
                hdop: data.hdop,
                accuracy: data.accuracy
            });
        }
    }

    handleSystemStatus(data) {
        console.log('System status:', data);
        
        if (window.messageManager && data.message) {
            const messageType = data.level || 'info';
            window.messageManager.addMessage(messageType, data.message);
        }
    }

    handleError(data) {
        console.error('Rover error:', data.message);
        
        if (window.messageManager) {
            window.messageManager.addMessage('error', `Rover error: ${data.message}`);
        }
    }

    handleHandshakeResponse(data) {
        console.log('Handshake response:', data);
        
        if (data.rover_info) {
            if (window.messageManager) {
                window.messageManager.addMessage('info', 
                    `Connected to ${data.rover_info.model || 'RTK3B Fusion'} rover`);
            }
        }
    }

    scheduleReconnect() {
        if (this.reconnectTimeout) {
            clearTimeout(this.reconnectTimeout);
        }

        this.reconnectAttempts++;
        const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts), 30000); // Exponential backoff, max 30s
        
        console.log(`Scheduling reconnect attempt ${this.reconnectAttempts} in ${delay}ms`);
        this.updateStatus('connecting', `Reconnecting in ${Math.ceil(delay/1000)}s...`);
        
        this.reconnectTimeout = setTimeout(() => {
            if (this.url) {
                const [protocol, rest] = this.url.split('://');
                const [address] = rest.split('/');
                const [ip, port] = address.split(':');
                this.connect(ip, port);
            }
        }, delay);
    }

    disconnect() {
        if (this.reconnectTimeout) {
            clearTimeout(this.reconnectTimeout);
            this.reconnectTimeout = null;
        }

        this.reconnectAttempts = this.maxReconnectAttempts; // Prevent auto-reconnect
        
        if (this.ws) {
            this.ws.close(1000, 'User disconnected');
            this.ws = null;
        }

        this.updateStatus('disconnected', 'Disconnected');
        this.enableConnectButton();
    }

    send(data) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            try {
                const message = JSON.stringify(data);
                this.ws.send(message);
                console.log('Sent message:', data);
                return true;
            } catch (error) {
                console.error('Error sending message:', error);
                return false;
            }
        } else {
            console.warn('WebSocket not connected, cannot send message');
            return false;
        }
    }

    updateStatus(status, text) {
        const statusElement = document.getElementById('connection-status');
        const textElement = document.getElementById('status-text');
        
        if (statusElement && textElement) {
            // Remove all status classes
            statusElement.classList.remove('connected', 'disconnected', 'connecting');
            // Add current status class
            statusElement.classList.add(status);
            // Update text
            textElement.textContent = text;
        }

        // Call external status change handler if set
        if (this.onStatusChange) {
            this.onStatusChange(status, text);
        }
    }

    enableConnectButton() {
        const connectBtn = document.getElementById('connect-btn');
        const disconnectBtn = document.getElementById('disconnect-btn');
        
        if (connectBtn && disconnectBtn) {
            connectBtn.disabled = false;
            disconnectBtn.disabled = true;
        }
    }

    enableDisconnectButton() {
        const connectBtn = document.getElementById('connect-btn');
        const disconnectBtn = document.getElementById('disconnect-btn');
        
        if (connectBtn && disconnectBtn) {
            connectBtn.disabled = true;
            disconnectBtn.disabled = false;
        }
    }

    isConnected() {
        return this.ws && this.ws.readyState === WebSocket.OPEN;
    }

    getConnectionState() {
        if (!this.ws) return 'disconnected';
        
        switch (this.ws.readyState) {
            case WebSocket.CONNECTING:
                return 'connecting';
            case WebSocket.OPEN:
                return 'connected';
            case WebSocket.CLOSING:
                return 'disconnecting';
            case WebSocket.CLOSED:
                return 'disconnected';
            default:
                return 'unknown';
        }
    }
}

// Global WebSocket instance
window.wsManager = null;