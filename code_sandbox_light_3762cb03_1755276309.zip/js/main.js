/**
 * Main Application Entry Point
 * Initializes all modules and handles global app logic
 */

class MessageManager {
    constructor() {
        this.messagesContainer = document.getElementById('messages-content');
        this.maxMessages = 50;
        this.setupEventListeners();
    }

    setupEventListeners() {
        const clearBtn = document.getElementById('clear-messages');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => this.clearMessages());
        }
    }

    addMessage(type, text, autoRemove = false) {
        if (!this.messagesContainer) return;

        const messageElement = document.createElement('div');
        messageElement.className = `message ${type}`;
        
        const iconMap = {
            info: 'fas fa-info-circle',
            success: 'fas fa-check-circle',
            warning: 'fas fa-exclamation-triangle',
            error: 'fas fa-times-circle'
        };

        messageElement.innerHTML = `
            <i class="${iconMap[type] || iconMap.info}"></i>
            <span>${text}</span>
            <small class="timestamp">${new Date().toLocaleTimeString()}</small>
        `;

        // Add message to top
        this.messagesContainer.insertBefore(messageElement, this.messagesContainer.firstChild);

        // Remove old messages if too many
        while (this.messagesContainer.children.length > this.maxMessages) {
            this.messagesContainer.removeChild(this.messagesContainer.lastChild);
        }

        // Auto-remove after delay if specified
        if (autoRemove) {
            setTimeout(() => {
                if (messageElement.parentNode) {
                    messageElement.parentNode.removeChild(messageElement);
                }
            }, 5000);
        }

        // Scroll to top
        this.messagesContainer.scrollTop = 0;
    }

    clearMessages() {
        if (this.messagesContainer) {
            this.messagesContainer.innerHTML = '';
            this.addMessage('info', 'Messages cleared');
        }
    }
}

class Application {
    constructor() {
        this.isInitialized = false;
        this.connectionSettings = {
            ip: '192.168.1.100',
            port: 8765
        };
        
        this.init();
    }

    async init() {
        try {
            console.log('Initializing RTK Drift Tracker application...');
            
            // Initialize managers
            this.initializeManagers();
            
            // Setup event listeners
            this.setupEventListeners();
            
            // Load saved settings
            this.loadSettings();
            
            // Initialize UI state
            this.initializeUI();
            
            this.isInitialized = true;
            console.log('Application initialized successfully');
            
            // Add welcome message
            window.messageManager.addMessage('info', 'RTK Drift Tracker initialized. Connect to rover to begin tracking.');
            
        } catch (error) {
            console.error('Failed to initialize application:', error);
            if (window.messageManager) {
                window.messageManager.addMessage('error', `Initialization failed: ${error.message}`);
            }
        }
    }

    initializeManagers() {
        // Initialize message manager first
        window.messageManager = new MessageManager();
        
        // Initialize map manager
        window.mapManager = new MapManager();
        
        // Initialize WebSocket manager
        window.wsManager = new WebSocketManager();
        
        // Initialize GPS tracker
        window.gpsTracker = new GPSTracker();
        
        // Set up manager interactions
        this.setupManagerInteractions();
    }

    setupManagerInteractions() {
        // WebSocket status change handler
        window.wsManager.onStatusChange = (status, text) => {
            console.log(`Connection status changed: ${status} - ${text}`);
        };

        // WebSocket message handler
        window.wsManager.onMessage = (data) => {
            // Additional message processing can be added here
        };

        // WebSocket error handler
        window.wsManager.onError = (error) => {
            console.error('WebSocket error:', error);
            window.messageManager.addMessage('error', 'WebSocket connection error');
        };
    }

    setupEventListeners() {
        // Connection controls
        const connectBtn = document.getElementById('connect-btn');
        const disconnectBtn = document.getElementById('disconnect-btn');
        const roverIpInput = document.getElementById('rover-ip');
        const roverPortInput = document.getElementById('rover-port');

        if (connectBtn) {
            connectBtn.addEventListener('click', () => {
                const ip = roverIpInput?.value || this.connectionSettings.ip;
                const port = parseInt(roverPortInput?.value) || this.connectionSettings.port;
                
                if (this.validateConnectionSettings(ip, port)) {
                    this.connectionSettings = { ip, port };
                    this.saveSettings();
                    window.wsManager.connect(ip, port);
                }
            });
        }

        if (disconnectBtn) {
            disconnectBtn.addEventListener('click', () => {
                window.wsManager.disconnect();
            });
        }

        // Input validation
        if (roverIpInput) {
            roverIpInput.addEventListener('change', () => {
                this.connectionSettings.ip = roverIpInput.value;
                this.saveSettings();
            });
        }

        if (roverPortInput) {
            roverPortInput.addEventListener('change', () => {
                this.connectionSettings.port = parseInt(roverPortInput.value);
                this.saveSettings();
            });
        }

        // Keyboard shortcuts
        document.addEventListener('keydown', (event) => {
            this.handleKeyboardShortcuts(event);
        });

        // Window events
        window.addEventListener('beforeunload', (event) => {
            this.handleBeforeUnload(event);
        });

        window.addEventListener('resize', () => {
            this.handleWindowResize();
        });
    }

    validateConnectionSettings(ip, port) {
        // Basic IP validation
        const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
        if (!ipRegex.test(ip)) {
            window.messageManager.addMessage('error', 'Invalid IP address format');
            return false;
        }

        // Check IP octets
        const octets = ip.split('.').map(Number);
        if (octets.some(octet => octet < 0 || octet > 255)) {
            window.messageManager.addMessage('error', 'Invalid IP address range');
            return false;
        }

        // Port validation
        if (port < 1 || port > 65535) {
            window.messageManager.addMessage('error', 'Port must be between 1 and 65535');
            return false;
        }

        return true;
    }

    handleKeyboardShortcuts(event) {
        // Ctrl/Cmd + shortcuts
        if (event.ctrlKey || event.metaKey) {
            switch (event.key.toLowerCase()) {
                case 'c':
                    if (event.shiftKey) {
                        event.preventDefault();
                        window.wsManager.connect(
                            this.connectionSettings.ip, 
                            this.connectionSettings.port
                        );
                    }
                    break;
                case 'd':
                    if (event.shiftKey) {
                        event.preventDefault();
                        window.wsManager.disconnect();
                    }
                    break;
                case 'r':
                    if (event.shiftKey) {
                        event.preventDefault();
                        if (window.gpsTracker.isRecording) {
                            window.gpsTracker.stopRecording();
                        } else {
                            window.gpsTracker.startRecording();
                        }
                    }
                    break;
                case 'm':
                    if (event.shiftKey) {
                        event.preventDefault();
                        window.mapManager.centerOnCar();
                    }
                    break;
            }
        }

        // Function keys
        switch (event.key) {
            case 'F11':
                event.preventDefault();
                window.mapManager.toggleFullscreen();
                break;
        }
    }

    handleBeforeUnload(event) {
        if (window.wsManager && window.wsManager.isConnected()) {
            event.preventDefault();
            event.returnValue = 'You are connected to the rover. Are you sure you want to leave?';
            return event.returnValue;
        }
    }

    handleWindowResize() {
        // Invalidate map size on window resize
        if (window.mapManager && window.mapManager.map) {
            setTimeout(() => {
                window.mapManager.map.invalidateSize();
            }, 100);
        }
    }

    loadSettings() {
        try {
            const saved = localStorage.getItem('rtk-drift-tracker-settings');
            if (saved) {
                const settings = JSON.parse(saved);
                this.connectionSettings = { ...this.connectionSettings, ...settings.connection };
            }
        } catch (error) {
            console.warn('Failed to load settings:', error);
        }
    }

    saveSettings() {
        try {
            const settings = {
                connection: this.connectionSettings,
                version: '1.0.0',
                lastSaved: Date.now()
            };
            localStorage.setItem('rtk-drift-tracker-settings', JSON.stringify(settings));
        } catch (error) {
            console.warn('Failed to save settings:', error);
        }
    }

    initializeUI() {
        // Set input values from settings
        const roverIpInput = document.getElementById('rover-ip');
        const roverPortInput = document.getElementById('rover-port');

        if (roverIpInput) {
            roverIpInput.value = this.connectionSettings.ip;
        }

        if (roverPortInput) {
            roverPortInput.value = this.connectionSettings.port;
        }

        // Initialize connection state
        window.wsManager.updateStatus('disconnected', 'Disconnected');
        window.wsManager.enableConnectButton();
    }

    // Public API methods
    getConnectionStatus() {
        return window.wsManager ? window.wsManager.getConnectionState() : 'disconnected';
    }

    getCurrentPosition() {
        return window.gpsTracker ? window.gpsTracker.getCurrentPosition() : null;
    }

    isRecording() {
        return window.gpsTracker ? window.gpsTracker.isCurrentlyRecording() : false;
    }

    exportData() {
        if (window.gpsTracker) {
            window.gpsTracker.exportTrack();
        }
    }

    clearData() {
        if (window.gpsTracker) {
            window.gpsTracker.clearTrack();
        }
    }
}

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new Application();
});

// Global error handler
window.addEventListener('error', (event) => {
    console.error('Global error:', event.error);
    if (window.messageManager) {
        window.messageManager.addMessage('error', `System error: ${event.error.message}`);
    }
});

// Global unhandled promise rejection handler
window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled promise rejection:', event.reason);
    if (window.messageManager) {
        window.messageManager.addMessage('error', `Promise error: ${event.reason}`);
    }
    event.preventDefault();
});

// Export global API for debugging
window.RTKTracker = {
    getApp: () => window.app,
    getMapManager: () => window.mapManager,
    getWebSocketManager: () => window.wsManager,
    getGPSTracker: () => window.gpsTracker,
    getMessageManager: () => window.messageManager
};