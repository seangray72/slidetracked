/**
 * GPS Tracking Module
 * Manages GPS data, recording, and statistics
 */

class GPSTracker {
    constructor() {
        this.isRecording = false;
        this.recordingStartTime = null;
        this.currentPosition = null;
        this.currentStatus = {
            fixType: 'No Fix',
            satellites: 0,
            hdop: null,
            accuracy: null
        };
        
        // Statistics
        this.maxSpeed = 0;
        this.totalDistance = 0;
        this.recordingDuration = 0;
        
        // Timer for duration update
        this.durationTimer = null;
        
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Recording controls
        const startBtn = document.getElementById('start-recording');
        const stopBtn = document.getElementById('stop-recording');
        const clearBtn = document.getElementById('clear-track');
        const exportBtn = document.getElementById('export-track');

        if (startBtn) {
            startBtn.addEventListener('click', () => this.startRecording());
        }
        
        if (stopBtn) {
            stopBtn.addEventListener('click', () => this.stopRecording());
        }
        
        if (clearBtn) {
            clearBtn.addEventListener('click', () => this.clearTrack());
        }
        
        if (exportBtn) {
            exportBtn.addEventListener('click', () => this.exportTrack());
        }
    }

    updatePosition(position) {
        this.currentPosition = position;
        
        // Update UI elements
        this.updatePositionUI(position);
        
        // Update statistics
        if (position.speed > this.maxSpeed) {
            this.maxSpeed = position.speed;
            this.updateStatisticsUI();
        }
        
        // Calculate distance if we have a previous position
        if (this.isRecording && window.mapManager && window.mapManager.trackPoints.length > 0) {
            this.updateDistance();
        }
    }

    updateStatus(status) {
        this.currentStatus = { ...this.currentStatus, ...status };
        this.updateStatusUI(this.currentStatus);
    }

    updatePositionUI(position) {
        const elements = {
            latitude: document.getElementById('latitude'),
            longitude: document.getElementById('longitude'),
            altitude: document.getElementById('altitude'),
            speed: document.getElementById('speed')
        };

        if (elements.latitude) {
            elements.latitude.textContent = position.latitude ? position.latitude.toFixed(6) : '-';
        }
        
        if (elements.longitude) {
            elements.longitude.textContent = position.longitude ? position.longitude.toFixed(6) : '-';
        }
        
        if (elements.altitude) {
            elements.altitude.textContent = position.altitude ? `${position.altitude.toFixed(1)}m` : '-';
        }
        
        if (elements.speed) {
            elements.speed.textContent = position.speed ? `${position.speed.toFixed(1)} km/h` : '0 km/h';
        }
    }

    updateStatusUI(status) {
        const elements = {
            fixType: document.getElementById('fix-type'),
            satellites: document.getElementById('satellites'),
            hdop: document.getElementById('hdop'),
            accuracy: document.getElementById('accuracy')
        };

        if (elements.fixType) {
            elements.fixType.textContent = status.fixType || 'No Fix';
            
            // Add status coloring
            elements.fixType.className = '';
            switch (status.fixType) {
                case 'RTK Fixed':
                    elements.fixType.style.color = '#48bb78';
                    elements.fixType.style.fontWeight = 'bold';
                    break;
                case 'RTK Float':
                    elements.fixType.style.color = '#ed8936';
                    elements.fixType.style.fontWeight = 'bold';
                    break;
                case '3D Fix':
                    elements.fixType.style.color = '#4299e1';
                    elements.fixType.style.fontWeight = 'normal';
                    break;
                default:
                    elements.fixType.style.color = '#f56565';
                    elements.fixType.style.fontWeight = 'normal';
            }
        }
        
        if (elements.satellites) {
            elements.satellites.textContent = status.satellites || '0';
            
            // Color code satellite count
            const satCount = parseInt(status.satellites) || 0;
            if (satCount >= 8) {
                elements.satellites.style.color = '#48bb78';
            } else if (satCount >= 4) {
                elements.satellites.style.color = '#ed8936';
            } else {
                elements.satellites.style.color = '#f56565';
            }
        }
        
        if (elements.hdop) {
            elements.hdop.textContent = status.hdop ? status.hdop.toFixed(2) : '-';
            
            // Color code HDOP (lower is better)
            const hdop = parseFloat(status.hdop);
            if (hdop && hdop <= 1.0) {
                elements.hdop.style.color = '#48bb78';
            } else if (hdop && hdop <= 2.0) {
                elements.hdop.style.color = '#ed8936';
            } else if (hdop) {
                elements.hdop.style.color = '#f56565';
            }
        }
        
        if (elements.accuracy) {
            elements.accuracy.textContent = status.accuracy ? `${status.accuracy.toFixed(2)}m` : '-';
            
            // Color code accuracy (lower is better)
            const acc = parseFloat(status.accuracy);
            if (acc && acc <= 0.1) {
                elements.accuracy.style.color = '#48bb78';
            } else if (acc && acc <= 1.0) {
                elements.accuracy.style.color = '#ed8936';
            } else if (acc) {
                elements.accuracy.style.color = '#f56565';
            }
        }
    }

    updateStatisticsUI() {
        const elements = {
            totalDistance: document.getElementById('total-distance'),
            maxSpeed: document.getElementById('max-speed'),
            duration: document.getElementById('duration')
        };

        if (elements.totalDistance) {
            elements.totalDistance.textContent = `${this.totalDistance.toFixed(2)} km`;
        }
        
        if (elements.maxSpeed) {
            elements.maxSpeed.textContent = `${this.maxSpeed.toFixed(1)} km/h`;
        }
        
        if (elements.duration) {
            elements.duration.textContent = this.formatDuration(this.recordingDuration);
        }
    }

    updateDistance() {
        if (window.mapManager) {
            this.totalDistance = window.mapManager.calculateTrackDistance();
            this.updateStatisticsUI();
        }
    }

    startRecording() {
        if (this.isRecording) return;
        
        this.isRecording = true;
        this.recordingStartTime = Date.now();
        this.maxSpeed = 0;
        this.totalDistance = 0;
        
        // Update UI
        const startBtn = document.getElementById('start-recording');
        const stopBtn = document.getElementById('stop-recording');
        
        if (startBtn) startBtn.disabled = true;
        if (stopBtn) stopBtn.disabled = false;
        
        // Start duration timer
        this.startDurationTimer();
        
        // Add message
        if (window.messageManager) {
            window.messageManager.addMessage('success', 'Recording started');
        }
        
        console.log('GPS recording started');
    }

    stopRecording() {
        if (!this.isRecording) return;
        
        this.isRecording = false;
        
        // Update UI
        const startBtn = document.getElementById('start-recording');
        const stopBtn = document.getElementById('stop-recording');
        
        if (startBtn) startBtn.disabled = false;
        if (stopBtn) stopBtn.disabled = true;
        
        // Stop duration timer
        this.stopDurationTimer();
        
        // Calculate final statistics
        const finalStats = this.getFinalStatistics();
        
        // Add message
        if (window.messageManager) {
            window.messageManager.addMessage('info', 
                `Recording stopped. Distance: ${finalStats.distance.toFixed(2)}km, Duration: ${this.formatDuration(finalStats.duration)}`);
        }
        
        console.log('GPS recording stopped', finalStats);
    }

    clearTrack() {
        // Clear map track
        if (window.mapManager) {
            window.mapManager.clearTrack();
        }
        
        // Reset statistics
        this.maxSpeed = 0;
        this.totalDistance = 0;
        this.recordingDuration = 0;
        
        // Update UI
        this.updateStatisticsUI();
        
        // Add message
        if (window.messageManager) {
            window.messageManager.addMessage('info', 'Track cleared');
        }
        
        console.log('Track cleared');
    }

    exportTrack() {
        if (!window.mapManager || window.mapManager.trackPoints.length === 0) {
            if (window.messageManager) {
                window.messageManager.addMessage('warning', 'No track data to export');
            }
            return;
        }
        
        const gpxData = window.mapManager.exportTrackAsGPX();
        if (!gpxData) {
            if (window.messageManager) {
                window.messageManager.addMessage('error', 'Failed to generate GPX data');
            }
            return;
        }
        
        // Create and download file
        const blob = new Blob([gpxData], { type: 'application/gpx+xml' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `drift-track-${new Date().toISOString().split('T')[0]}.gpx`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        URL.revokeObjectURL(url);
        
        // Add message
        if (window.messageManager) {
            window.messageManager.addMessage('success', 'Track exported as GPX file');
        }
        
        console.log('Track exported as GPX');
    }

    startDurationTimer() {
        if (this.durationTimer) {
            clearInterval(this.durationTimer);
        }
        
        this.durationTimer = setInterval(() => {
            if (this.isRecording && this.recordingStartTime) {
                this.recordingDuration = Date.now() - this.recordingStartTime;
                this.updateStatisticsUI();
            }
        }, 1000);
    }

    stopDurationTimer() {
        if (this.durationTimer) {
            clearInterval(this.durationTimer);
            this.durationTimer = null;
        }
    }

    formatDuration(milliseconds) {
        const seconds = Math.floor(milliseconds / 1000);
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;
        
        return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }

    getFinalStatistics() {
        const stats = {
            distance: this.totalDistance,
            maxSpeed: this.maxSpeed,
            duration: this.recordingDuration,
            averageSpeed: 0,
            points: 0
        };
        
        if (window.mapManager) {
            const mapStats = window.mapManager.getTrackStatistics();
            stats.distance = mapStats.distance;
            stats.points = mapStats.points;
            
            // Calculate average speed
            if (this.recordingDuration > 0) {
                stats.averageSpeed = (stats.distance / (this.recordingDuration / 1000 / 3600)); // km/h
            }
        }
        
        return stats;
    }

    getCurrentPosition() {
        return this.currentPosition;
    }

    getCurrentStatus() {
        return this.currentStatus;
    }

    isCurrentlyRecording() {
        return this.isRecording;
    }
}

// Global GPS tracker instance
window.gpsTracker = null;