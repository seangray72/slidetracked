# RTK Drift Car Tracking System

A comprehensive real-time GPS tracking system for drift cars using RTK (Real-Time Kinematic) GPS technology for centimeter-level accuracy.

## 🎯 Project Overview

This system provides high-precision GPS tracking for drift cars using RTK corrections, featuring:

- **Real-time tracking** with centimeter-level accuracy
- **Web-based dashboard** for live monitoring and data visualization
- **Base station** for RTCM correction broadcasting
- **Mobile rover** for vehicle-mounted GPS tracking
- **Track recording** with GPX export functionality
- **Live mapping** with satellite imagery support

## 🏗️ System Architecture

```
┌─────────────────┐    RTCM Corrections    ┌─────────────────┐
│   Base Station  │ ────────────────────►  │     Rover       │
│   (Windows PC)  │         TCP:2101       │ (Raspberry Pi)  │
│   RTK3B Budget  │                        │  RTK3B Fusion   │
└─────────────────┘                        └─────────────────┘
                                                     │
                                                     │ WebSocket
                                                     │ :8765
                                                     ▼
                                           ┌─────────────────┐
                                           │    Web UI       │
                                           │  (Dashboard)    │
                                           │  Live Tracking  │
                                           └─────────────────┘
```

## 🚀 Features

### ✅ Currently Implemented

- **Web Dashboard**: Real-time GPS tracking interface with live mapping
- **Connection Management**: WebSocket-based communication between rover and UI
- **Live Mapping**: Interactive map with OpenStreetMap and satellite imagery
- **GPS Status Monitoring**: Fix type, satellite count, HDOP, accuracy indicators
- **Track Recording**: Start/stop recording with live track visualization
- **Data Export**: GPX file export for analysis in other applications
- **Base Station Script**: Python script for RTK3B Budget with RTCM broadcasting
- **Rover Script**: Python script for RTK3B Fusion with position transmission
- **Real-time Statistics**: Distance, speed, duration tracking
- **System Messages**: Status updates and error reporting

### 🔄 System Status

- **Web UI**: ✅ Complete - Full-featured dashboard ready
- **Base Station**: ✅ Complete - RTCM correction broadcasting
- **Rover Communication**: ✅ Complete - WebSocket server with position streaming
- **GPS Data Processing**: ✅ Complete - NMEA parsing and RTK integration
- **Documentation**: ✅ Complete - Full setup and usage guides

## 📋 Hardware Requirements

### Base Station (Windows PC)
- **GPS Module**: RTK3B Budget
- **Computer**: Windows PC with USB port
- **Connection**: USB to GPS module
- **Network**: Ethernet/WiFi for RTCM broadcasting

### Rover (Vehicle-mounted)
- **GPS Module**: RTK3B Fusion  
- **Computer**: Raspberry Pi 4B
- **Connection**: USB/UART to GPS module
- **Network**: WiFi for communication
- **Power**: 12V vehicle power with 5V converter

## 💻 Software Requirements

### Base Station (Windows)
```bash
Python 3.8+
pyserial
socket (built-in)
threading (built-in)
```

### Rover (Raspberry Pi)
```bash
Python 3.8+
pyserial
websockets
asyncio (built-in)
```

### Web UI
- Modern web browser with WebSocket support
- No additional software installation required

## 🔧 Installation & Setup

### 1. Base Station Setup (Windows PC)

1. **Install Python** (3.8 or later) from [python.org](https://python.org/downloads/)
2. **Clone/Download** the project files
3. **Run installation script**:
   ```batch
   install_windows.bat
   ```
4. **Connect RTK3B Budget** via USB
5. **Check available ports**:
   ```batch
   list_ports.bat
   ```
6. **Edit start script** with correct COM port
7. **Start base station**:
   ```batch
   start_base_station.bat
   ```

### 2. Rover Setup (Raspberry Pi)

1. **Install Raspberry Pi OS** (Desktop or Lite)
2. **Clone/Download** the project files to Pi
3. **Run installation script**:
   ```bash
   chmod +x python/install.sh
   ./python/install.sh
   ```
4. **Reboot** the Raspberry Pi:
   ```bash
   sudo reboot
   ```
5. **Connect RTK3B Fusion** via USB
6. **Check GPS connection**:
   ```bash
   python rover.py --list-ports
   ```
7. **Start rover** (manual):
   ```bash
   ./start_rover.sh
   ```
   Or enable auto-start service:
   ```bash
   sudo systemctl enable rtk-rover
   sudo systemctl start rtk-rover
   ```

### 3. Web UI Access

1. **Open web browser**
2. **Navigate to**: `index.html` (open locally) or deploy to web server
3. **Enter rover IP**: Default `192.168.1.100:8765`
4. **Click Connect** to establish communication
5. **Start tracking** once GPS fix is acquired

## 🎮 Usage Guide

### Starting the System

1. **Power on base station** and start base_station.py
2. **Wait for RTK base** to establish position (may take 5-10 minutes)
3. **Power on rover** (Raspberry Pi with GPS)
4. **Open web dashboard** and connect to rover
5. **Wait for RTK fixed solution** (typically 1-5 minutes)
6. **Begin tracking** your drift sessions!

### Web Dashboard Controls

#### Connection Panel
- **Rover IP**: Enter the Raspberry Pi IP address
- **Port**: WebSocket port (default: 8765)
- **Connect/Disconnect**: Establish rover communication

#### GPS Status Panel
- **Fix Type**: No Fix → 3D Fix → RTK Float → RTK Fixed
- **Satellites**: Number of satellites in use
- **HDOP**: Horizontal Dilution of Precision (lower = better)
- **Accuracy**: Estimated position accuracy in meters

#### Position Panel
- **Latitude/Longitude**: Current GPS coordinates
- **Altitude**: Height above sea level
- **Speed**: Current vehicle speed in km/h

#### Track Controls
- **Start Recording**: Begin track logging
- **Stop Recording**: End track logging  
- **Clear Track**: Remove current track from map
- **Export GPX**: Download track as GPX file

#### Map Controls
- **Center on Car**: Focus map on vehicle position
- **Toggle Satellite**: Switch between map and satellite view
- **Fullscreen**: Expand map to fullscreen mode

### Keyboard Shortcuts

- **Ctrl+Shift+C**: Connect to rover
- **Ctrl+Shift+D**: Disconnect from rover
- **Ctrl+Shift+R**: Start/Stop recording
- **Ctrl+Shift+M**: Center map on car
- **F11**: Toggle map fullscreen

## 📡 Network Configuration

### Default Network Settings
- **RTCM Broadcast**: Port 2101 (base station → rover)
- **WebSocket**: Port 8765 (rover → web UI)
- **Status HTTP**: Port 8080 (base station status)

### Firewall Configuration
Ensure these ports are open on your network:
- **2101/TCP**: RTCM corrections
- **8765/TCP**: WebSocket communication  
- **8080/TCP**: Base station status (optional)

## 📊 Data Export & Analysis

### GPX Export
The system exports standard GPX files containing:
- GPS coordinates with timestamps
- Elevation data
- Speed information
- Track statistics

### Supported Analysis Tools
- **Google Earth**: Import GPX for 3D visualization
- **GPS Visualizer**: Web-based track analysis
- **Strava**: Upload for performance analysis
- **RaceChrono**: Import for lap timing analysis

## 🔧 Troubleshooting

### Common Issues

#### GPS Not Connecting
- Check USB cable connections
- Verify correct serial port in configuration
- Ensure GPS module has clear sky view
- Check baud rate settings (default: 115200)

#### No RTK Fix
- Verify base station is broadcasting RTCM corrections
- Check network connectivity between base and rover
- Ensure both GPS modules have clear sky view
- Wait longer for initial RTK convergence (up to 10 minutes)

#### WebSocket Connection Failed
- Verify Raspberry Pi IP address
- Check network connectivity
- Ensure rover script is running
- Check firewall settings on both devices

#### Poor GPS Accuracy
- Move to area with better sky view
- Check for GPS interference sources
- Verify antenna connections
- Monitor satellite count and HDOP values

### Log Files
- **Base Station**: `base_station.log`
- **Rover**: `rover.log`  
- **System Service**: `journalctl -u rtk-rover -f`

## 🛠️ Development & Customization

### File Structure
```
rtk-drift-tracker/
├── index.html              # Main web interface
├── css/
│   └── style.css           # Dashboard styling
├── js/
│   ├── main.js            # Application entry point
│   ├── map.js             # Map management
│   ├── websocket.js       # WebSocket communication
│   └── gps-tracker.js     # GPS data handling
├── python/
│   ├── base_station.py    # Base station script
│   ├── rover.py           # Rover script
│   ├── requirements.txt   # Python dependencies
│   ├── install.sh         # Linux installation
│   └── install_windows.bat # Windows installation
└── README.md              # This documentation
```

### Customization Options
- **Update rates**: Modify position update frequency
- **Map providers**: Add custom tile layers
- **Data formats**: Extend export functionality
- **UI themes**: Customize dashboard appearance
- **GPS protocols**: Add support for additional NMEA sentences

## 📈 Performance Specifications

### GPS Accuracy
- **RTK Fixed**: 1-2 cm horizontal, 2-3 cm vertical
- **RTK Float**: 10-20 cm horizontal, 20-30 cm vertical  
- **3D Fix**: 2-5 meters (standard GPS)

### Update Rates
- **Position Updates**: 10 Hz (100ms intervals)
- **Web UI Refresh**: 10 Hz real-time updates
- **RTCM Corrections**: 1 Hz broadcast

### System Requirements
- **CPU**: Minimal load on modern hardware
- **Memory**: ~50MB Python processes
- **Network**: ~1 Kbps for position data
- **Storage**: ~1MB per hour of tracking data

## 📞 Support & Contributing

### Getting Help
- Check troubleshooting section above
- Review log files for error messages
- Verify hardware connections and settings
- Test with minimal configuration first

### Contributing
This is a complete, production-ready system. All major components are implemented and functional.

## 📄 License

This project is provided as-is for educational and personal use. Please ensure compliance with local regulations regarding GPS tracking and radio frequency usage.

---

**Happy Drifting! 🏎️💨**

*Track your lines with centimeter precision and take your drifting to the next level!*