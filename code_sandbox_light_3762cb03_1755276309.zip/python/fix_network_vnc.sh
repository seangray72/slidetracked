#!/bin/bash
# Network and VNC Recovery Script for Raspberry Pi
# Run this script via SSH/Putty to restore network and VNC connectivity

echo "========================================="
echo "Raspberry Pi Network & VNC Recovery"
echo "========================================="

# Function to check if running as root
check_root() {
    if [ "$EUID" -eq 0 ]; then
        echo "Please run this script as a regular user, not root"
        echo "Use: bash fix_network_vnc.sh"
        exit 1
    fi
}

# Function to backup current config
backup_configs() {
    echo "Creating backup of current configurations..."
    sudo cp /boot/config.txt /boot/config.txt.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
    sudo cp /etc/dhcpcd.conf /etc/dhcpcd.conf.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
    sudo cp /etc/wpa_supplicant/wpa_supplicant.conf /etc/wpa_supplicant/wpa_supplicant.conf.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
}

# Function to re-enable VNC
enable_vnc() {
    echo "Re-enabling VNC server..."
    
    # Enable VNC via raspi-config
    sudo raspi-config nonint do_vnc 0
    
    # Ensure VNC service is enabled and started
    sudo systemctl enable vncserver-x11-serviced
    sudo systemctl start vncserver-x11-serviced
    
    # Check VNC status
    if sudo systemctl is-active --quiet vncserver-x11-serviced; then
        echo "✓ VNC server is running"
    else
        echo "⚠ VNC server failed to start, trying alternative method..."
        sudo systemctl restart vncserver-x11-serviced
    fi
}

# Function to fix WiFi configuration
fix_wifi() {
    echo "Checking WiFi configuration..."
    
    # Ensure WiFi interface is up
    sudo ip link set wlan0 up 2>/dev/null || true
    
    # Restart WiFi services
    sudo systemctl restart dhcpcd
    sudo systemctl restart wpa_supplicant
    
    # Check if wpa_supplicant config exists and has networks
    if [ -f /etc/wpa_supplicant/wpa_supplicant.conf ]; then
        echo "WiFi configuration file exists"
        # Show configured networks (without passwords)
        echo "Configured networks:"
        grep -E "ssid=" /etc/wpa_supplicant/wpa_supplicant.conf | sed 's/.*ssid="\([^"]*\)".*/  - \1/'
    else
        echo "⚠ WiFi configuration file missing"
    fi
    
    # Try to reconnect to WiFi
    sudo wpa_cli -i wlan0 reconfigure 2>/dev/null || true
    sleep 5
    
    # Check WiFi status
    if iwconfig wlan0 | grep -q "ESSID:"; then
        echo "✓ WiFi is connected"
        iwconfig wlan0 | grep "ESSID:"
    else
        echo "⚠ WiFi not connected"
    fi
}

# Function to check and fix network services
fix_network_services() {
    echo "Checking network services..."
    
    # Ensure essential services are enabled
    sudo systemctl enable networking
    sudo systemctl enable dhcpcd
    sudo systemctl enable wpa_supplicant
    
    # Restart network services
    sudo systemctl restart networking
    sudo systemctl restart dhcpcd
    
    echo "✓ Network services restarted"
}

# Function to restore boot config if needed
fix_boot_config() {
    echo "Checking boot configuration..."
    
    # Ensure essential boot options are enabled
    sudo raspi-config nonint do_ssh 0          # Enable SSH
    sudo raspi-config nonint do_vnc 0          # Enable VNC
    sudo raspi-config nonint do_camera 0       # Enable camera (if needed)
    
    # Check if config.txt has the right settings
    if ! grep -q "dtparam=i2c_arm=on" /boot/config.txt; then
        echo "dtparam=i2c_arm=on" | sudo tee -a /boot/config.txt > /dev/null
    fi
    
    if ! grep -q "dtparam=spi=on" /boot/config.txt; then
        echo "dtparam=spi=on" | sudo tee -a /boot/config.txt > /dev/null
    fi
    
    echo "✓ Boot configuration checked"
}

# Function to show current network status
show_status() {
    echo ""
    echo "========================================="
    echo "Current Network Status"
    echo "========================================="
    
    echo "IP Addresses:"
    ip addr show | grep -E "inet.*scope global" | awk '{print "  " $NF ": " $2}'
    
    echo ""
    echo "WiFi Status:"
    iwconfig wlan0 2>/dev/null | grep -E "ESSID|Quality|Bit Rate" || echo "  WiFi interface not found or not connected"
    
    echo ""
    echo "Active Services:"
    services=("ssh" "vncserver-x11-serviced" "dhcpcd" "wpa_supplicant")
    for service in "${services[@]}"; do
        if sudo systemctl is-active --quiet $service; then
            echo "  ✓ $service is running"
        else
            echo "  ✗ $service is not running"
        fi
    done
    
    echo ""
    echo "Network Interfaces:"
    ip link show | grep -E "^[0-9]:" | awk '{print "  " $2}' | sed 's/:$//'
}

# Function to add WiFi network interactively
add_wifi_network() {
    echo ""
    echo "========================================="
    echo "Add WiFi Network"
    echo "========================================="
    
    read -p "Enter WiFi network name (SSID): " ssid
    if [ -z "$ssid" ]; then
        echo "SSID cannot be empty"
        return 1
    fi
    
    read -s -p "Enter WiFi password: " password
    echo ""
    
    if [ -z "$password" ]; then
        echo "Password cannot be empty"
        return 1
    fi
    
    # Add network to wpa_supplicant
    echo "Adding network to WiFi configuration..."
    
    # Create wpa_supplicant config if it doesn't exist
    if [ ! -f /etc/wpa_supplicant/wpa_supplicant.conf ]; then
        sudo tee /etc/wpa_supplicant/wpa_supplicant.conf > /dev/null << EOF
country=US
ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev
update_config=1
EOF
    fi
    
    # Add the network
    wpa_passphrase "$ssid" "$password" | sudo tee -a /etc/wpa_supplicant/wpa_supplicant.conf > /dev/null
    
    # Restart WiFi services
    sudo systemctl restart wpa_supplicant
    sudo systemctl restart dhcpcd
    
    echo "✓ WiFi network added. Attempting to connect..."
    sleep 10
    
    # Check connection
    if iwconfig wlan0 | grep -q "ESSID:\"$ssid\""; then
        echo "✓ Successfully connected to $ssid"
        return 0
    else
        echo "⚠ Failed to connect to $ssid. Please check credentials."
        return 1
    fi
}

# Main script execution
main() {
    check_root
    
    echo "Starting recovery process..."
    echo ""
    
    backup_configs
    
    echo "1. Fixing network services..."
    fix_network_services
    
    echo "2. Fixing WiFi configuration..."
    fix_wifi
    
    echo "3. Re-enabling VNC..."
    enable_vnc
    
    echo "4. Checking boot configuration..."
    fix_boot_config
    
    echo ""
    echo "Recovery process completed!"
    
    show_status
    
    echo ""
    echo "========================================="
    echo "Next Steps"
    echo "========================================="
    echo "1. If WiFi is not connected, run this script with 'wifi' option:"
    echo "   bash fix_network_vnc.sh wifi"
    echo ""
    echo "2. Try connecting via VNC to your Pi's IP address"
    echo ""
    echo "3. If still having issues, reboot the Pi:"
    echo "   sudo reboot"
    echo ""
    echo "4. SSH should remain available at your Pi's IP address"
}

# Handle command line arguments
case "${1:-}" in
    "wifi")
        echo "WiFi network setup mode..."
        add_wifi_network
        ;;
    "status")
        show_status
        ;;
    *)
        main
        ;;
esac