#!/usr/bin/env python3
"""
RTK Base Station Script for Windows PC
Handles RTK3B Budget GPS module and broadcasts RTCM corrections

Hardware Requirements:
- RTK3B Budget GPS module
- Windows PC with available serial port

Software Requirements:
- pyserial
- socket (built-in)
- threading (built-in)

Author: RTK Drift Tracker System
Version: 1.0.0
"""

import serial
import socket
import threading
import time
import logging
import json
import argparse
from datetime import datetime
from typing import Optional, Dict, Any
import sys
import os

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('base_station.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('BaseStation')

class RTK3BParser:
    """Parser for RTK3B Budget GPS data"""
    
    def __init__(self):
        self.buffer = b''
        
    def parse_nmea(self, line: str) -> Optional[Dict[str, Any]]:
        """Parse NMEA sentence"""
        try:
            if not line.startswith('$'):
                return None
                
            parts = line.strip().split(',')
            sentence_type = parts[0][1:]  # Remove $
            
            if sentence_type == 'GPGGA':
                return self._parse_gga(parts)
            elif sentence_type == 'GPRMC':
                return self._parse_rmc(parts)
            elif sentence_type == 'GPGSV':
                return self._parse_gsv(parts)
                
        except Exception as e:
            logger.debug(f"Error parsing NMEA: {e}")
            
        return None
    
    def _parse_gga(self, parts: list) -> Optional[Dict[str, Any]]:
        """Parse GGA sentence (Global Positioning System Fix Data)"""
        try:
            if len(parts) < 15:
                return None
                
            data = {
                'type': 'position',
                'timestamp': datetime.utcnow().isoformat(),
                'time': parts[1],
                'latitude': self._convert_coordinate(parts[2], parts[3]),
                'longitude': self._convert_coordinate(parts[4], parts[5]),
                'fix_quality': int(parts[6]) if parts[6] else 0,
                'satellites': int(parts[7]) if parts[7] else 0,
                'hdop': float(parts[8]) if parts[8] else 0.0,
                'altitude': float(parts[9]) if parts[9] else 0.0,
                'geoid_height': float(parts[11]) if parts[11] else 0.0
            }
            
            # Fix quality interpretation
            fix_types = {
                0: 'No Fix',
                1: '3D Fix',
                2: 'DGPS Fix',
                4: 'RTK Fixed',
                5: 'RTK Float'
            }
            data['fix_type'] = fix_types.get(data['fix_quality'], 'Unknown')
            
            return data
            
        except Exception as e:
            logger.debug(f"Error parsing GGA: {e}")
            return None
    
    def _parse_rmc(self, parts: list) -> Optional[Dict[str, Any]]:
        """Parse RMC sentence (Recommended Minimum Course)"""
        try:
            if len(parts) < 12:
                return None
                
            data = {
                'type': 'velocity',
                'timestamp': datetime.utcnow().isoformat(),
                'time': parts[1],
                'status': parts[2],
                'latitude': self._convert_coordinate(parts[3], parts[4]),
                'longitude': self._convert_coordinate(parts[5], parts[6]),
                'speed_knots': float(parts[7]) if parts[7] else 0.0,
                'course': float(parts[8]) if parts[8] else 0.0,
                'date': parts[9]
            }
            
            # Convert speed to km/h
            data['speed_kmh'] = data['speed_knots'] * 1.852
            
            return data
            
        except Exception as e:
            logger.debug(f"Error parsing RMC: {e}")
            return None
    
    def _parse_gsv(self, parts: list) -> Optional[Dict[str, Any]]:
        """Parse GSV sentence (Satellites in View)"""
        try:
            if len(parts) < 4:
                return None
                
            data = {
                'type': 'satellites',
                'timestamp': datetime.utcnow().isoformat(),
                'total_messages': int(parts[1]) if parts[1] else 0,
                'message_number': int(parts[2]) if parts[2] else 0,
                'satellites_in_view': int(parts[3]) if parts[3] else 0,
                'satellites': []
            }
            
            # Parse satellite info (4 satellites per message max)
            for i in range(4, len(parts), 4):
                if i + 3 < len(parts):
                    sat_info = {
                        'prn': int(parts[i]) if parts[i] else 0,
                        'elevation': int(parts[i+1]) if parts[i+1] else 0,
                        'azimuth': int(parts[i+2]) if parts[i+2] else 0,
                        'snr': int(parts[i+3].split('*')[0]) if parts[i+3] and parts[i+3].split('*')[0] else 0
                    }
                    data['satellites'].append(sat_info)
            
            return data
            
        except Exception as e:
            logger.debug(f"Error parsing GSV: {e}")
            return None
    
    def _convert_coordinate(self, coord_str: str, direction: str) -> Optional[float]:
        """Convert NMEA coordinate format to decimal degrees"""
        try:
            if not coord_str or not direction:
                return None
                
            # NMEA format: DDMM.MMMM or DDDMM.MMMM
            if len(coord_str) >= 7:
                if len(coord_str) == 9:  # Longitude DDDMM.MMMM
                    degrees = int(coord_str[:3])
                    minutes = float(coord_str[3:])
                else:  # Latitude DDMM.MMMM
                    degrees = int(coord_str[:2])
                    minutes = float(coord_str[2:])
                
                decimal = degrees + minutes / 60.0
                
                if direction in ['S', 'W']:
                    decimal = -decimal
                    
                return decimal
                
        except Exception as e:
            logger.debug(f"Error converting coordinate: {e}")
            
        return None

class RTCMBroadcaster:
    """Broadcasts RTCM corrections to rovers"""
    
    def __init__(self, port: int = 2101):
        self.port = port
        self.clients = []
        self.server_socket = None
        self.running = False
        self.lock = threading.Lock()
        
    def start(self):
        """Start RTCM broadcast server"""
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind(('0.0.0.0', self.port))
            self.server_socket.listen(5)
            
            self.running = True
            logger.info(f"RTCM broadcast server started on port {self.port}")
            
            # Start client acceptance thread
            threading.Thread(target=self._accept_clients, daemon=True).start()
            
        except Exception as e:
            logger.error(f"Failed to start RTCM broadcaster: {e}")
            self.running = False
    
    def stop(self):
        """Stop RTCM broadcast server"""
        self.running = False
        
        with self.lock:
            # Close all client connections
            for client in self.clients:
                try:
                    client.close()
                except:
                    pass
            self.clients.clear()
        
        if self.server_socket:
            try:
                self.server_socket.close()
            except:
                pass
            
        logger.info("RTCM broadcast server stopped")
    
    def _accept_clients(self):
        """Accept client connections"""
        while self.running:
            try:
                client_socket, address = self.server_socket.accept()
                logger.info(f"RTCM client connected from {address}")
                
                with self.lock:
                    self.clients.append(client_socket)
                    
            except Exception as e:
                if self.running:
                    logger.error(f"Error accepting client: {e}")
                break
    
    def broadcast_rtcm(self, data: bytes):
        """Broadcast RTCM data to all connected clients"""
        if not data:
            return
            
        with self.lock:
            disconnected_clients = []
            
            for client in self.clients:
                try:
                    client.send(data)
                except Exception as e:
                    logger.debug(f"Failed to send to client: {e}")
                    disconnected_clients.append(client)
            
            # Remove disconnected clients
            for client in disconnected_clients:
                self.clients.remove(client)
                try:
                    client.close()
                except:
                    pass
                    
        if disconnected_clients:
            logger.info(f"Removed {len(disconnected_clients)} disconnected RTCM clients")

class BaseStation:
    """Main base station controller"""
    
    def __init__(self, serial_port: str, baud_rate: int = 115200, rtcm_port: int = 2101):
        self.serial_port = serial_port
        self.baud_rate = baud_rate
        self.rtcm_port = rtcm_port
        
        self.serial_conn = None
        self.parser = RTK3BParser()
        self.rtcm_broadcaster = RTCMBroadcaster(rtcm_port)
        self.status_server = None
        
        self.running = False
        self.last_position = None
        self.last_status = None
        self.statistics = {
            'start_time': datetime.utcnow(),
            'messages_processed': 0,
            'rtcm_messages_sent': 0,
            'connected_rovers': 0
        }
    
    def start(self):
        """Start the base station"""
        logger.info("Starting RTK Base Station...")
        
        try:
            # Initialize serial connection
            self.serial_conn = serial.Serial(
                port=self.serial_port,
                baudrate=self.baud_rate,
                timeout=1,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE
            )
            logger.info(f"Connected to RTK3B Budget on {self.serial_port} at {self.baud_rate} baud")
            
            # Start RTCM broadcaster
            self.rtcm_broadcaster.start()
            
            # Start status server
            self._start_status_server()
            
            self.running = True
            self.statistics['start_time'] = datetime.utcnow()
            
            # Start main processing loop
            self._run_main_loop()
            
        except Exception as e:
            logger.error(f"Failed to start base station: {e}")
            self.stop()
    
    def stop(self):
        """Stop the base station"""
        logger.info("Stopping RTK Base Station...")
        
        self.running = False
        
        if self.serial_conn and self.serial_conn.is_open:
            self.serial_conn.close()
            
        self.rtcm_broadcaster.stop()
        
        if self.status_server:
            self.status_server.close()
            
        logger.info("Base station stopped")
    
    def _run_main_loop(self):
        """Main processing loop"""
        logger.info("Base station running. Press Ctrl+C to stop.")
        
        try:
            while self.running:
                # Read from serial port
                if self.serial_conn and self.serial_conn.in_waiting > 0:
                    try:
                        data = self.serial_conn.read(self.serial_conn.in_waiting)
                        self._process_serial_data(data)
                    except Exception as e:
                        logger.error(f"Error reading serial data: {e}")
                
                # Small delay to prevent CPU overload
                time.sleep(0.01)
                
        except KeyboardInterrupt:
            logger.info("Received interrupt signal")
        except Exception as e:
            logger.error(f"Error in main loop: {e}")
        finally:
            self.stop()
    
    def _process_serial_data(self, data: bytes):
        """Process incoming serial data"""
        try:
            # Check if data contains RTCM messages (binary data starting with 0xD3)
            if data.startswith(b'\xD3'):
                self._handle_rtcm_data(data)
                return
            
            # Try to decode as NMEA text
            try:
                text = data.decode('ascii', errors='ignore')
                lines = text.strip().split('\n')
                
                for line in lines:
                    line = line.strip()
                    if line:
                        self._handle_nmea_data(line)
                        
            except UnicodeDecodeError:
                # Might be binary RTCM data
                self._handle_rtcm_data(data)
                
        except Exception as e:
            logger.debug(f"Error processing serial data: {e}")
    
    def _handle_nmea_data(self, line: str):
        """Handle NMEA data from GPS"""
        parsed = self.parser.parse_nmea(line)
        if parsed:
            self.statistics['messages_processed'] += 1
            
            if parsed['type'] == 'position':
                self.last_position = parsed
                logger.info(f"Base position: {parsed['latitude']:.6f}, {parsed['longitude']:.6f} "
                          f"(Fix: {parsed['fix_type']}, Sats: {parsed['satellites']})")
                          
            elif parsed['type'] == 'satellites':
                self.last_status = parsed
                logger.debug(f"Satellites in view: {parsed['satellites_in_view']}")
    
    def _handle_rtcm_data(self, data: bytes):
        """Handle RTCM correction data"""
        try:
            # Validate RTCM message structure
            if len(data) >= 3 and data[0] == 0xD3:
                # Extract message length
                length = ((data[1] & 0x03) << 8) | data[2]
                
                if len(data) >= length + 6:  # 3 header + length + 3 CRC
                    # Broadcast to connected rovers
                    self.rtcm_broadcaster.broadcast_rtcm(data)
                    self.statistics['rtcm_messages_sent'] += 1
                    
                    # Update connected rovers count
                    self.statistics['connected_rovers'] = len(self.rtcm_broadcaster.clients)
                    
                    logger.debug(f"Broadcasted RTCM message (type: {(data[3] << 4) | (data[4] >> 4)}, "
                               f"length: {length}) to {self.statistics['connected_rovers']} rovers")
                    
        except Exception as e:
            logger.debug(f"Error handling RTCM data: {e}")
    
    def _start_status_server(self):
        """Start HTTP status server for monitoring"""
        try:
            from http.server import HTTPServer, BaseHTTPRequestHandler
            import json
            
            class StatusHandler(BaseHTTPRequestHandler):
                def do_GET(self):
                    if self.path == '/status':
                        self.send_response(200)
                        self.send_header('Content-type', 'application/json')
                        self.send_header('Access-Control-Allow-Origin', '*')
                        self.end_headers()
                        
                        status = {
                            'running': base_station.running,
                            'uptime_seconds': (datetime.utcnow() - base_station.statistics['start_time']).total_seconds(),
                            'last_position': base_station.last_position,
                            'last_status': base_station.last_status,
                            'statistics': base_station.statistics,
                            'rtcm_clients': len(base_station.rtcm_broadcaster.clients)
                        }
                        
                        self.wfile.write(json.dumps(status, indent=2).encode())
                    else:
                        self.send_response(404)
                        self.end_headers()
                
                def log_message(self, format, *args):
                    pass  # Suppress HTTP log messages
            
            base_station = self
            self.status_server = HTTPServer(('0.0.0.0', 8080), StatusHandler)
            threading.Thread(target=self.status_server.serve_forever, daemon=True).start()
            logger.info("Status server started on http://localhost:8080/status")
            
        except Exception as e:
            logger.warning(f"Failed to start status server: {e}")

def find_serial_ports():
    """Find available serial ports"""
    import serial.tools.list_ports
    
    ports = serial.tools.list_ports.comports()
    available_ports = []
    
    for port in ports:
        available_ports.append({
            'device': port.device,
            'description': port.description,
            'hwid': port.hwid
        })
    
    return available_ports

def main():
    parser = argparse.ArgumentParser(description='RTK Base Station for RTK3B Budget')
    parser.add_argument('--port', '-p', type=str, required=True,
                       help='Serial port for RTK3B Budget (e.g., COM3, /dev/ttyUSB0)')
    parser.add_argument('--baud', '-b', type=int, default=115200,
                       help='Baud rate (default: 115200)')
    parser.add_argument('--rtcm-port', '-r', type=int, default=2101,
                       help='RTCM broadcast port (default: 2101)')
    parser.add_argument('--list-ports', '-l', action='store_true',
                       help='List available serial ports')
    parser.add_argument('--verbose', '-v', action='store_true',
                       help='Enable verbose logging')
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    if args.list_ports:
        print("Available serial ports:")
        ports = find_serial_ports()
        for port in ports:
            print(f"  {port['device']}: {port['description']}")
        return
    
    # Create and start base station
    base_station = BaseStation(
        serial_port=args.port,
        baud_rate=args.baud,
        rtcm_port=args.rtcm_port
    )
    
    try:
        base_station.start()
    except KeyboardInterrupt:
        logger.info("Shutdown requested by user")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
    finally:
        base_station.stop()

if __name__ == '__main__':
    main()