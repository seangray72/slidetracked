#!/bin/bash
# RTK Drift Tracker Installation Script for Raspberry Pi
# Run this script to install all required dependencies

set -e  # Exit on any error

echo "========================================="
echo "RTK Drift Tracker System Installation"
echo "========================================="

# Check if running on Raspberry Pi
if ! grep -q "Raspberry Pi" /proc/cpuinfo 2>/dev/null; then
    echo "Warning: This script is optimized for Raspberry Pi"
    read -p "Continue anyway? (y/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Update system packages
echo "Updating system packages..."
sudo apt update
sudo apt upgrade -y

# Install Python 3 and pip if not already installed
echo "Installing Python 3 and pip..."
sudo apt install -y python3 python3-pip python3-venv

# Install system dependencies
echo "Installing system dependencies..."
sudo apt install -y \
    git \
    wget \
    curl \
    screen \
    htop \
    usbutils \
    minicom

# Create virtual environment
echo "Creating Python virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Upgrade pip
echo "Upgrading pip..."
pip install --upgrade pip

# Install Python requirements
echo "Installing Python requirements..."
pip install -r requirements.txt

# Set up serial port permissions
echo "Setting up serial port permissions..."
sudo usermod -a -G dialout $USER
sudo usermod -a -G tty $USER

# Create systemd service file for rover
echo "Creating systemd service..."
sudo tee /etc/systemd/system/rtk-rover.service > /dev/null <<EOF
[Unit]
Description=RTK Drift Tracker Rover
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$(pwd)
Environment=PATH=$(pwd)/venv/bin
ExecStart=$(pwd)/venv/bin/python $(pwd)/rover.py --port /dev/ttyUSB0 --base-ip 192.168.1.100
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

# Enable I2C and SPI (might be needed for some GPS modules)
echo "Enabling I2C and SPI..."
sudo raspi-config nonint do_i2c 0
sudo raspi-config nonint do_spi 0

# Disable serial console (enable serial port for GPS)
echo "Configuring serial port..."
sudo raspi-config nonint do_serial 1  # Disable serial console
sudo raspi-config nonint do_serial_hw 0  # Enable serial port hardware

# Create log directory
mkdir -p logs

# Create start script
cat > start_rover.sh << 'EOF'
#!/bin/bash
# Start RTK Rover script
cd "$(dirname "$0")"
source venv/bin/activate
python rover.py --port /dev/ttyUSB0 --base-ip 192.168.1.100 --verbose
EOF

chmod +x start_rover.sh

# Create stop script
cat > stop_rover.sh << 'EOF'
#!/bin/bash
# Stop RTK Rover service
sudo systemctl stop rtk-rover
EOF

chmod +x stop_rover.sh

echo ""
echo "========================================="
echo "Installation Complete!"
echo "========================================="
echo ""
echo "Next steps:"
echo "1. Reboot your Raspberry Pi: sudo reboot"
echo "2. Connect your RTK3B Fusion GPS module"
echo "3. Check available serial ports: python rover.py --list-ports"
echo "4. Edit the service file if needed: sudo systemctl edit rtk-rover"
echo "5. Start the rover service: sudo systemctl start rtk-rover"
echo "6. Enable auto-start: sudo systemctl enable rtk-rover"
echo ""
echo "Useful commands:"
echo "- Start rover manually: ./start_rover.sh"
echo "- Check service status: sudo systemctl status rtk-rover"
echo "- View logs: journalctl -u rtk-rover -f"
echo "- View rover logs: tail -f rover.log"
echo ""
echo "The rover will be accessible at ws://$(hostname -I | awk '{print $1}'):8765"
echo ""