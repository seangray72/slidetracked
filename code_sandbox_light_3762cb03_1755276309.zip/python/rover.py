#!/usr/bin/env python3
"""
RTK Rover Script for Raspberry Pi
Handles RTK3B Fusion GPS module, receives RTCM corrections, and transmits position data

Hardware Requirements:
- RTK3B Fusion GPS module
- Raspberry Pi 4B
- Network connection (WiFi/Ethernet)

Software Requirements:
- pyserial
- websockets
- asyncio (built-in)
- threading (built-in)

Author: RTK Drift Tracker System
Version: 1.0.0
"""

import serial
import socket
import asyncio
import websockets
import threading
import time
import logging
import json
import argparse
from datetime import datetime
from typing import Optional, Dict, Any, List
import sys
import os
import signal
from dataclasses import dataclass

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('rover.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('Rover')

@dataclass
class GPSPosition:
    """GPS position data structure"""
    latitude: float
    longitude: float
    altitude: float
    speed: float
    heading: float
    timestamp: datetime
    fix_type: str
    satellites: int
    hdop: float
    accuracy: float

@dataclass
class GPSStatus:
    """GPS status data structure"""
    fix_type: str
    satellites: int
    hdop: float
    accuracy: float
    timestamp: datetime

class RTK3BFusionParser:
    """Parser for RTK3B Fusion GPS data"""
    
    def __init__(self):
        self.buffer = b''
        self.last_position = None
        self.last_velocity = None
        
    def parse_nmea(self, line: str) -> Optional[Dict[str, Any]]:
        """Parse NMEA sentence"""
        try:
            if not line.startswith('$'):
                return None
                
            parts = line.strip().split(',')
            sentence_type = parts[0][1:]  # Remove $
            
            if sentence_type == 'GPGGA' or sentence_type == 'GNGGA':
                return self._parse_gga(parts)
            elif sentence_type == 'GPRMC' or sentence_type == 'GNRMC':
                return self._parse_rmc(parts)
            elif sentence_type == 'GPGSV' or sentence_type == 'GNGSV':
                return self._parse_gsv(parts)
            elif sentence_type == 'GPHDT':
                return self._parse_hdt(parts)
                
        except Exception as e:
            logger.debug(f"Error parsing NMEA: {e}")
            
        return None
    
    def _parse_gga(self, parts: list) -> Optional[Dict[str, Any]]:
        """Parse GGA sentence (Global Positioning System Fix Data)"""
        try:
            if len(parts) < 15:
                return None
                
            latitude = self._convert_coordinate(parts[2], parts[3])
            longitude = self._convert_coordinate(parts[4], parts[5])
            
            if latitude is None or longitude is None:
                return None
                
            data = {
                'type': 'position',
                'timestamp': datetime.utcnow().isoformat(),
                'time': parts[1],
                'latitude': latitude,
                'longitude': longitude,
                'fix_quality': int(parts[6]) if parts[6] else 0,
                'satellites': int(parts[7]) if parts[7] else 0,
                'hdop': float(parts[8]) if parts[8] else 99.99,
                'altitude': float(parts[9]) if parts[9] else 0.0,
                'geoid_height': float(parts[11]) if parts[11] else 0.0
            }
            
            # Fix quality interpretation for RTK3B Fusion
            fix_types = {
                0: 'No Fix',
                1: '3D Fix',
                2: 'DGPS Fix',
                3: 'PPS Fix',
                4: 'RTK Fixed',
                5: 'RTK Float',
                6: 'Dead Reckoning',
                7: 'Manual Input',
                8: 'Simulation'
            }
            data['fix_type'] = fix_types.get(data['fix_quality'], 'Unknown')
            
            # Calculate accuracy estimate based on HDOP and fix type
            hdop = data['hdop']
            if data['fix_quality'] == 4:  # RTK Fixed
                data['accuracy'] = hdop * 0.01  # Very high accuracy
            elif data['fix_quality'] == 5:  # RTK Float
                data['accuracy'] = hdop * 0.1   # High accuracy
            elif data['fix_quality'] >= 1:  # 3D Fix or better
                data['accuracy'] = hdop * 2.5   # Standard GPS accuracy
            else:
                data['accuracy'] = 99.99
            
            self.last_position = data
            return data
            
        except Exception as e:
            logger.debug(f"Error parsing GGA: {e}")
            return None
    
    def _parse_rmc(self, parts: list) -> Optional[Dict[str, Any]]:
        """Parse RMC sentence (Recommended Minimum Course)"""
        try:
            if len(parts) < 12:
                return None
                
            latitude = self._convert_coordinate(parts[3], parts[4])
            longitude = self._convert_coordinate(parts[5], parts[6])
            
            if latitude is None or longitude is None:
                return None
                
            data = {
                'type': 'velocity',
                'timestamp': datetime.utcnow().isoformat(),
                'time': parts[1],
                'status': parts[2],
                'latitude': latitude,
                'longitude': longitude,
                'speed_knots': float(parts[7]) if parts[7] else 0.0,
                'course': float(parts[8]) if parts[8] else 0.0,
                'date': parts[9],
                'magnetic_variation': float(parts[10]) if parts[10] else 0.0
            }
            
            # Convert speed to km/h and m/s
            data['speed_kmh'] = data['speed_knots'] * 1.852
            data['speed_ms'] = data['speed_knots'] * 0.514444
            
            self.last_velocity = data
            return data
            
        except Exception as e:
            logger.debug(f"Error parsing RMC: {e}")
            return None
    
    def _parse_gsv(self, parts: list) -> Optional[Dict[str, Any]]:
        """Parse GSV sentence (Satellites in View)"""
        try:
            if len(parts) < 4:
                return None
                
            data = {
                'type': 'satellites',
                'timestamp': datetime.utcnow().isoformat(),
                'total_messages': int(parts[1]) if parts[1] else 0,
                'message_number': int(parts[2]) if parts[2] else 0,
                'satellites_in_view': int(parts[3]) if parts[3] else 0,
                'satellites': []
            }
            
            # Parse satellite info (4 satellites per message max)
            for i in range(4, min(len(parts), 20), 4):  # Max 4 satellites per GSV message
                if i + 3 < len(parts):
                    snr_field = parts[i+3].split('*')[0] if '*' in parts[i+3] else parts[i+3]
                    sat_info = {
                        'prn': int(parts[i]) if parts[i] else 0,
                        'elevation': int(parts[i+1]) if parts[i+1] else 0,
                        'azimuth': int(parts[i+2]) if parts[i+2] else 0,
                        'snr': int(snr_field) if snr_field else 0
                    }
                    data['satellites'].append(sat_info)
            
            return data
            
        except Exception as e:
            logger.debug(f"Error parsing GSV: {e}")
            return None
    
    def _parse_hdt(self, parts: list) -> Optional[Dict[str, Any]]:
        """Parse HDT sentence (Heading - True)"""
        try:
            if len(parts) < 3:
                return None
                
            data = {
                'type': 'heading',
                'timestamp': datetime.utcnow().isoformat(),
                'heading_true': float(parts[1]) if parts[1] else 0.0
            }
            
            return data
            
        except Exception as e:
            logger.debug(f"Error parsing HDT: {e}")
            return None
    
    def _convert_coordinate(self, coord_str: str, direction: str) -> Optional[float]:
        """Convert NMEA coordinate format to decimal degrees"""
        try:
            if not coord_str or not direction:
                return None
                
            # NMEA format: DDMM.MMMM or DDDMM.MMMM
            if len(coord_str) >= 7:
                if len(coord_str) >= 9 and '.' in coord_str[3:]:  # Longitude DDDMM.MMMM
                    degrees = int(coord_str[:3])
                    minutes = float(coord_str[3:])
                else:  # Latitude DDMM.MMMM
                    degrees = int(coord_str[:2])
                    minutes = float(coord_str[2:])
                
                decimal = degrees + minutes / 60.0
                
                if direction in ['S', 'W']:
                    decimal = -decimal
                    
                return decimal
                
        except Exception as e:
            logger.debug(f"Error converting coordinate: {e}")
            
        return None
    
    def get_combined_position(self) -> Optional[GPSPosition]:
        """Get combined position data from last GGA and RMC messages"""
        if not self.last_position:
            return None
            
        position = self.last_position
        velocity = self.last_velocity or {}
        
        return GPSPosition(
            latitude=position['latitude'],
            longitude=position['longitude'],
            altitude=position['altitude'],
            speed=velocity.get('speed_kmh', 0.0),
            heading=velocity.get('course', 0.0),
            timestamp=datetime.utcnow(),
            fix_type=position['fix_type'],
            satellites=position['satellites'],
            hdop=position['hdop'],
            accuracy=position['accuracy']
        )

class RTCMClient:
    """Client for receiving RTCM corrections from base station"""
    
    def __init__(self, base_station_ip: str, base_station_port: int = 2101):
        self.base_station_ip = base_station_ip
        self.base_station_port = base_station_port
        self.socket = None
        self.running = False
        self.reconnect_delay = 5
        self.on_rtcm_data = None
        
    def start(self):
        """Start RTCM client"""
        self.running = True
        threading.Thread(target=self._run_client, daemon=True).start()
        logger.info(f"RTCM client started, connecting to {self.base_station_ip}:{self.base_station_port}")
    
    def stop(self):
        """Stop RTCM client"""
        self.running = False
        if self.socket:
            try:
                self.socket.close()
            except:
                pass
        logger.info("RTCM client stopped")
    
    def _run_client(self):
        """Main client loop"""
        while self.running:
            try:
                self._connect_and_receive()
            except Exception as e:
                logger.error(f"RTCM client error: {e}")
                
            if self.running:
                logger.info(f"Reconnecting to RTCM server in {self.reconnect_delay} seconds...")
                time.sleep(self.reconnect_delay)
    
    def _connect_and_receive(self):
        """Connect to base station and receive RTCM data"""
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(10)
            self.socket.connect((self.base_station_ip, self.base_station_port))
            logger.info(f"Connected to RTCM server at {self.base_station_ip}:{self.base_station_port}")
            
            while self.running:
                data = self.socket.recv(1024)
                if not data:
                    break
                    
                if self.on_rtcm_data:
                    self.on_rtcm_data(data)
                    
        except Exception as e:
            if self.running:
                logger.warning(f"RTCM connection lost: {e}")
        finally:
            if self.socket:
                try:
                    self.socket.close()
                except:
                    pass
                self.socket = None

class WebSocketServer:
    """WebSocket server for communicating with web UI"""
    
    def __init__(self, port: int = 8765):
        self.port = port
        self.clients = set()
        self.server = None
        self.running = False
        
    async def start(self):
        """Start WebSocket server"""
        try:
            self.server = await websockets.serve(
                self.handle_client, 
                "0.0.0.0", 
                self.port,
                ping_interval=20,
                ping_timeout=10
            )
            self.running = True
            logger.info(f"WebSocket server started on port {self.port}")
        except Exception as e:
            logger.error(f"Failed to start WebSocket server: {e}")
    
    async def stop(self):
        """Stop WebSocket server"""
        self.running = False
        if self.server:
            self.server.close()
            await self.server.wait_closed()
        logger.info("WebSocket server stopped")
    
    async def handle_client(self, websocket, path):
        """Handle client connection"""
        client_addr = websocket.remote_address
        logger.info(f"WebSocket client connected from {client_addr}")
        
        self.clients.add(websocket)
        
        try:
            async for message in websocket:
                await self.handle_message(websocket, message)
        except websockets.exceptions.ConnectionClosed:
            logger.info(f"WebSocket client {client_addr} disconnected")
        except Exception as e:
            logger.error(f"WebSocket client error: {e}")
        finally:
            self.clients.discard(websocket)
    
    async def handle_message(self, websocket, message):
        """Handle incoming message from client"""
        try:
            data = json.loads(message)
            logger.debug(f"Received message: {data}")
            
            if data.get('type') == 'handshake':
                response = {
                    'type': 'handshake_response',
                    'status': 'connected',
                    'rover_info': {
                        'model': 'RTK3B Fusion',
                        'version': '1.0.0'
                    },
                    'timestamp': datetime.utcnow().isoformat()
                }
                await websocket.send(json.dumps(response))
                
        except Exception as e:
            logger.error(f"Error handling message: {e}")
    
    async def broadcast_position(self, position: GPSPosition):
        """Broadcast position update to all clients"""
        if not self.clients:
            return
            
        message = {
            'type': 'gps_position',
            'latitude': position.latitude,
            'longitude': position.longitude,
            'altitude': position.altitude,
            'speed': position.speed,
            'heading': position.heading,
            'timestamp': position.timestamp.isoformat()
        }
        
        await self._broadcast_message(message)
    
    async def broadcast_status(self, status: GPSStatus):
        """Broadcast GPS status to all clients"""
        if not self.clients:
            return
            
        message = {
            'type': 'gps_status',
            'fix_type': status.fix_type,
            'satellites': status.satellites,
            'hdop': status.hdop,
            'accuracy': status.accuracy,
            'timestamp': status.timestamp.isoformat()
        }
        
        await self._broadcast_message(message)
    
    async def _broadcast_message(self, message: dict):
        """Broadcast message to all connected clients"""
        if not self.clients:
            return
            
        message_json = json.dumps(message)
        disconnected_clients = set()
        
        for client in self.clients.copy():
            try:
                await client.send(message_json)
            except websockets.exceptions.ConnectionClosed:
                disconnected_clients.add(client)
            except Exception as e:
                logger.debug(f"Error sending to client: {e}")
                disconnected_clients.add(client)
        
        # Remove disconnected clients
        self.clients -= disconnected_clients

class Rover:
    """Main rover controller"""
    
    def __init__(self, serial_port: str, baud_rate: int = 115200, 
                 base_station_ip: str = None, websocket_port: int = 8765):
        self.serial_port = serial_port
        self.baud_rate = baud_rate
        self.base_station_ip = base_station_ip
        self.websocket_port = websocket_port
        
        self.serial_conn = None
        self.parser = RTK3BFusionParser()
        self.rtcm_client = None
        self.websocket_server = WebSocketServer(websocket_port)
        
        self.running = False
        self.last_position_time = 0
        self.position_update_interval = 0.1  # 10Hz position updates
        
        # Statistics
        self.statistics = {
            'start_time': datetime.utcnow(),
            'positions_sent': 0,
            'rtcm_messages_received': 0,
            'websocket_clients': 0
        }
        
        # Setup signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        logger.info(f"Received signal {signum}, shutting down...")
        self.running = False
    
    async def start(self):
        """Start the rover"""
        logger.info("Starting RTK Rover...")
        
        try:
            # Initialize serial connection
            self.serial_conn = serial.Serial(
                port=self.serial_port,
                baudrate=self.baud_rate,
                timeout=0.1,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE
            )
            logger.info(f"Connected to RTK3B Fusion on {self.serial_port} at {self.baud_rate} baud")
            
            # Start RTCM client if base station is configured
            if self.base_station_ip:
                self.rtcm_client = RTCMClient(self.base_station_ip)
                self.rtcm_client.on_rtcm_data = self._handle_rtcm_data
                self.rtcm_client.start()
            
            # Start WebSocket server
            await self.websocket_server.start()
            
            self.running = True
            self.statistics['start_time'] = datetime.utcnow()
            
            # Start main processing loop
            await self._run_main_loop()
            
        except Exception as e:
            logger.error(f"Failed to start rover: {e}")
            await self.stop()
    
    async def stop(self):
        """Stop the rover"""
        logger.info("Stopping RTK Rover...")
        
        self.running = False
        
        if self.serial_conn and self.serial_conn.is_open:
            self.serial_conn.close()
            
        if self.rtcm_client:
            self.rtcm_client.stop()
            
        await self.websocket_server.stop()
        
        logger.info("Rover stopped")
    
    async def _run_main_loop(self):
        """Main processing loop"""
        logger.info("Rover running. Press Ctrl+C to stop.")
        
        try:
            while self.running:
                # Read from serial port
                if self.serial_conn and self.serial_conn.in_waiting > 0:
                    try:
                        data = self.serial_conn.read(self.serial_conn.in_waiting)
                        await self._process_serial_data(data)
                    except Exception as e:
                        logger.error(f"Error reading serial data: {e}")
                
                # Update statistics
                self.statistics['websocket_clients'] = len(self.websocket_server.clients)
                
                # Small delay to prevent CPU overload
                await asyncio.sleep(0.01)
                
        except Exception as e:
            logger.error(f"Error in main loop: {e}")
        finally:
            await self.stop()
    
    async def _process_serial_data(self, data: bytes):
        """Process incoming serial data"""
        try:
            # Decode as NMEA text
            text = data.decode('ascii', errors='ignore')
            lines = text.strip().split('\n')
            
            for line in lines:
                line = line.strip()
                if line:
                    await self._handle_nmea_data(line)
                    
        except Exception as e:
            logger.debug(f"Error processing serial data: {e}")
    
    async def _handle_nmea_data(self, line: str):
        """Handle NMEA data from GPS"""
        parsed = self.parser.parse_nmea(line)
        if not parsed:
            return
            
        current_time = time.time()
        
        if parsed['type'] == 'position':
            # Send position updates at controlled rate
            if current_time - self.last_position_time >= self.position_update_interval:
                position = self.parser.get_combined_position()
                if position:
                    await self.websocket_server.broadcast_position(position)
                    self.statistics['positions_sent'] += 1
                    self.last_position_time = current_time
                    
                    logger.debug(f"Position: {position.latitude:.6f}, {position.longitude:.6f} "
                               f"(Fix: {position.fix_type}, Sats: {position.satellites}, "
                               f"Speed: {position.speed:.1f} km/h)")
                    
        elif parsed['type'] == 'satellites':
            # Broadcast satellite status
            status = GPSStatus(
                fix_type=self.parser.last_position['fix_type'] if self.parser.last_position else 'No Fix',
                satellites=parsed['satellites_in_view'],
                hdop=self.parser.last_position['hdop'] if self.parser.last_position else 99.99,
                accuracy=self.parser.last_position['accuracy'] if self.parser.last_position else 99.99,
                timestamp=datetime.utcnow()
            )
            await self.websocket_server.broadcast_status(status)
    
    def _handle_rtcm_data(self, data: bytes):
        """Handle RTCM correction data from base station"""
        try:
            # Forward RTCM data to GPS module
            if self.serial_conn and self.serial_conn.is_open:
                self.serial_conn.write(data)
                self.statistics['rtcm_messages_received'] += 1
                logger.debug(f"Forwarded {len(data)} bytes of RTCM data to GPS")
                
        except Exception as e:
            logger.error(f"Error handling RTCM data: {e}")

def find_serial_ports():
    """Find available serial ports"""
    import serial.tools.list_ports
    
    ports = serial.tools.list_ports.comports()
    available_ports = []
    
    for port in ports:
        available_ports.append({
            'device': port.device,
            'description': port.description,
            'hwid': port.hwid
        })
    
    return available_ports

async def main():
    parser = argparse.ArgumentParser(description='RTK Rover for RTK3B Fusion')
    parser.add_argument('--port', '-p', type=str, required=True,
                       help='Serial port for RTK3B Fusion (e.g., /dev/ttyUSB0, /dev/ttyAMA0)')
    parser.add_argument('--baud', '-b', type=int, default=115200,
                       help='Baud rate (default: 115200)')
    parser.add_argument('--base-ip', '-i', type=str,
                       help='Base station IP address for RTCM corrections')
    parser.add_argument('--base-port', '-r', type=int, default=2101,
                       help='Base station RTCM port (default: 2101)')
    parser.add_argument('--websocket-port', '-w', type=int, default=8765,
                       help='WebSocket server port (default: 8765)')
    parser.add_argument('--list-ports', '-l', action='store_true',
                       help='List available serial ports')
    parser.add_argument('--verbose', '-v', action='store_true',
                       help='Enable verbose logging')
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    if args.list_ports:
        print("Available serial ports:")
        ports = find_serial_ports()
        for port in ports:
            print(f"  {port['device']}: {port['description']}")
        return
    
    # Create and start rover
    rover = Rover(
        serial_port=args.port,
        baud_rate=args.baud,
        base_station_ip=args.base_ip,
        websocket_port=args.websocket_port
    )
    
    try:
        await rover.start()
    except KeyboardInterrupt:
        logger.info("Shutdown requested by user")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
    finally:
        await rover.stop()

if __name__ == '__main__':
    asyncio.run(main())