#!/bin/bash
# Quick WiFi Recovery Script
# Use this if you need to quickly reconnect to WiFi via SSH/Putty

echo "Quick WiFi Recovery for Raspberry Pi"
echo "====================================="

# Function to restart WiFi services
restart_wifi() {
    echo "Restarting WiFi services..."
    sudo systemctl restart wpa_supplicant
    sudo systemctl restart dhcpcd
    sudo ip link set wlan0 down
    sleep 2
    sudo ip link set wlan0 up
    sleep 5
    echo "WiFi services restarted"
}

# Function to scan for networks
scan_networks() {
    echo "Scanning for available WiFi networks..."
    sudo iwlist wlan0 scan | grep "ESSID:" | sort | uniq
}

# Function to show current status
show_wifi_status() {
    echo ""
    echo "Current WiFi Status:"
    echo "==================="
    
    # Show interface status
    ip addr show wlan0 2>/dev/null | grep "inet " | awk '{print "IP Address: " $2}'
    
    # Show connected network
    iwconfig wlan0 2>/dev/null | grep "ESSID:" | awk -F'"' '{print "Connected to: " $2}'
    
    # Show signal quality
    iwconfig wlan0 2>/dev/null | grep "Link Quality" | awk '{print "Signal: " $2 " " $3}'
}

# Function to add WiFi network quickly
quick_add_wifi() {
    echo ""
    echo "Add WiFi Network"
    echo "================"
    
    # Show available networks first
    echo "Available networks:"
    sudo iwlist wlan0 scan 2>/dev/null | grep "ESSID:" | sed 's/.*ESSID:"\([^"]*\)".*/  \1/' | grep -v "^$" | sort | uniq
    
    echo ""
    read -p "Enter WiFi name (SSID): " wifi_ssid
    if [ -z "$wifi_ssid" ]; then
        echo "Error: SSID cannot be empty"
        return 1
    fi
    
    read -s -p "Enter WiFi password: " wifi_password
    echo ""
    
    if [ -z "$wifi_password" ]; then
        echo "Error: Password cannot be empty"
        return 1
    fi
    
    # Backup existing config
    sudo cp /etc/wpa_supplicant/wpa_supplicant.conf /etc/wpa_supplicant/wpa_supplicant.conf.backup 2>/dev/null || true
    
    # Create minimal wpa_supplicant config
    sudo tee /etc/wpa_supplicant/wpa_supplicant.conf > /dev/null << EOF
country=US
ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev
update_config=1

network={
    ssid="$wifi_ssid"
    psk="$wifi_password"
    key_mgmt=WPA-PSK
}
EOF
    
    echo "WiFi configuration updated. Connecting..."
    restart_wifi
    
    # Wait for connection
    echo "Waiting for WiFi connection..."
    for i in {1..30}; do
        if iwconfig wlan0 2>/dev/null | grep -q "ESSID:\"$wifi_ssid\""; then
            echo "✓ Connected to $wifi_ssid!"
            show_wifi_status
            return 0
        fi
        echo -n "."
        sleep 1
    done
    
    echo ""
    echo "⚠ Connection timeout. Please check:"
    echo "  - WiFi name (SSID) is correct"
    echo "  - Password is correct"
    echo "  - Network is in range"
}

# Function to reconnect to existing networks
reconnect_wifi() {
    echo "Attempting to reconnect to configured networks..."
    
    if [ ! -f /etc/wpa_supplicant/wpa_supplicant.conf ]; then
        echo "No WiFi configuration found. Please add a network first."
        return 1
    fi
    
    # Show configured networks
    echo "Configured networks:"
    grep "ssid=" /etc/wpa_supplicant/wpa_supplicant.conf | sed 's/.*ssid="\([^"]*\)".*/  \1/'
    
    restart_wifi
    
    echo "Waiting for connection..."
    for i in {1..20}; do
        if iwconfig wlan0 2>/dev/null | grep -q "ESSID:"; then
            echo "✓ WiFi reconnected!"
            show_wifi_status
            return 0
        fi
        echo -n "."
        sleep 1
    done
    
    echo ""
    echo "⚠ Failed to reconnect. Try adding the network again."
}

# Function to enable VNC quickly
enable_vnc_quick() {
    echo "Enabling VNC server..."
    
    # Enable VNC
    sudo systemctl enable vncserver-x11-serviced
    sudo systemctl start vncserver-x11-serviced
    
    # Enable via raspi-config
    sudo raspi-config nonint do_vnc 0
    
    if sudo systemctl is-active --quiet vncserver-x11-serviced; then
        echo "✓ VNC server is now running"
        echo "You should be able to connect via VNC once WiFi is working"
    else
        echo "⚠ VNC server failed to start"
    fi
}

# Main menu
main_menu() {
    echo ""
    echo "Select an option:"
    echo "1) Show WiFi status"
    echo "2) Reconnect to existing WiFi"
    echo "3) Add new WiFi network"
    echo "4) Restart WiFi services"
    echo "5) Enable VNC"
    echo "6) Scan for networks"
    echo "7) Exit"
    echo ""
    read -p "Choice [1-7]: " choice
    
    case $choice in
        1) show_wifi_status ;;
        2) reconnect_wifi ;;
        3) quick_add_wifi ;;
        4) restart_wifi && show_wifi_status ;;
        5) enable_vnc_quick ;;
        6) scan_networks ;;
        7) echo "Goodbye!"; exit 0 ;;
        *) echo "Invalid choice" ;;
    esac
}

# Check if argument provided
if [ $# -eq 0 ]; then
    # Interactive mode
    while true; do
        main_menu
        echo ""
        read -p "Press Enter to continue or Ctrl+C to exit..."
    done
else
    # Command line mode
    case "$1" in
        "status") show_wifi_status ;;
        "restart") restart_wifi && show_wifi_status ;;
        "scan") scan_networks ;;
        "vnc") enable_vnc_quick ;;
        "add") quick_add_wifi ;;
        "reconnect") reconnect_wifi ;;
        *)
            echo "Usage: $0 [status|restart|scan|vnc|add|reconnect]"
            echo "Or run without arguments for interactive mode"
            ;;
    esac
fi